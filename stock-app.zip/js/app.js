// CORE APPLICATION STATE
let activeMode = 'IN';
let inventoryData = JSON.parse(localStorage.getItem('stock_items_fixed') || '[]');
let sessionUser = JSON.parse(sessionStorage.getItem('session_user_fixed') || 'null');
let auditList = [];
let html5QrCode = null;
let isCooldown = false;

window.addEventListener('DOMContentLoaded', () => {
  lucide.createIcons();
  checkAuth();
  renderTable();
  updateStats();
});

function checkAuth() {
  const modal = document.getElementById('login-modal');
  const settingsBtn = document.getElementById('nav-btn-settings');
  if (!sessionUser) {
    modal.classList.remove('hidden');
  } else {
    modal.classList.add('hidden');
    document.getElementById('nav-username').innerText = sessionUser.name;
    document.getElementById('nav-userrole').innerText = sessionUser.role;
    if (sessionUser.role === 'Admin') settingsBtn.classList.remove('hidden');
  }
}

function handleLoginSubmit(e) {
  e.preventDefault();
  const u = document.getElementById('input-username').value.trim();
  const p = document.getElementById('input-password').value.trim();
  const errorBanner = document.getElementById('login-error-banner');
  const card = document.getElementById('login-card-container');

  if (u.toLowerCase() === 'admin' && p === '8888') {
    sessionUser = { name: 'អ្នកគ្រប់គ្រង (Admin)', role: 'Admin' };
    sessionStorage.setItem('session_user_fixed', JSON.stringify(sessionUser));
    checkAuth();
    showToast('សូមស្វាគមន៍ Admin!', 'success');
  } else {
    errorBanner.classList.remove('hidden');
    card.classList.remove('shake-anim');
    void card.offsetWidth;
    card.classList.add('shake-anim');
  }
}

function handleLogout() {
  sessionUser = null;
  sessionStorage.removeItem('session_user_fixed');
  stopScannerCamera();
  location.reload();
}

function switchNavTab(tab) {
  document.getElementById('tab-inventory').classList.add('hidden');
  document.getElementById('tab-audit').classList.add('hidden');
  document.getElementById('nav-btn-inventory').className = "px-3 py-1.5 rounded-lg text-slate-400 hover:text-white";
  document.getElementById('nav-btn-audit').className = "px-3 py-1.5 rounded-lg text-slate-400 hover:text-white";

  if (tab === 'inventory') {
    document.getElementById('tab-inventory').classList.remove('hidden');
    document.getElementById('nav-btn-inventory').className = "px-3 py-1.5 rounded-lg bg-cyan-600 text-white";
  } else {
    document.getElementById('tab-audit').classList.remove('hidden');
    document.getElementById('nav-btn-audit').className = "px-3 py-1.5 rounded-lg bg-cyan-600 text-white";
  }
  lucide.createIcons();
}

function changeMode(mode) {
  activeMode = mode;
  if (mode === 'IN') {
    document.getElementById('btn-mode-in').className = "px-3 py-1.5 rounded-lg bg-cyan-600 text-white";
    document.getElementById('btn-mode-out').className = "px-3 py-1.5 rounded-lg text-slate-400";
  } else {
    document.getElementById('btn-mode-out').className = "px-3 py-1.5 rounded-lg bg-emerald-600 text-white";
    document.getElementById('btn-mode-in').className = "px-3 py-1.5 rounded-lg text-slate-400";
  }
}

function startScannerCamera() {
  if (location.protocol !== 'https:' && location.hostname !== 'localhost' && location.hostname !== '127.0.0.1') {
    alert('សូមដំណើរការលើ HTTPS (ដូចជា Netlify ឬ Localhost) ទើបអាចបើកកាមេរ៉ាស្កេនបាន!');
  }
  html5QrCode = new Html5Qrcode("reader");
  html5QrCode.start(
    { facingMode: "environment" },
    { fps: 15, qrbox: { width: 220, height: 220 } },
    (decodedText) => handleScanAction(decodedText)
  ).then(() => {
    document.getElementById('btn-cam-start').classList.add('hidden');
    document.getElementById('btn-cam-stop').classList.remove('hidden');
    document.getElementById('camera-idle').classList.add('hidden');
    document.getElementById('laser-line').classList.remove('hidden');
  }).catch(err => {
    showToast('មិនអាចបើកកាមេរ៉ាបានទេ: ' + err, 'error');
  });
}

function stopScannerCamera() {
  if (html5QrCode) {
    html5QrCode.stop().then(() => {
      document.getElementById('btn-cam-start').classList.remove('hidden');
      document.getElementById('btn-cam-stop').classList.add('hidden');
      document.getElementById('camera-idle').classList.remove('hidden');
      document.getElementById('laser-line').classList.add('hidden');
    }).catch(e => console.error(e));
  }
}

function handleScanManualSubmit() {
  const code = document.getElementById('scan-manual-tracking-input').value.trim();
  if (!code) return;
  handleScanAction(code);
  document.getElementById('scan-manual-tracking-input').value = '';
}

function handleScanAction(code) {
  if (isCooldown) return;
  isCooldown = true;

  if (activeMode === 'IN') {
    const exist = inventoryData.find(i => i.barcode === code);
    if (exist) {
      showToast(`ទំនិញ [${code}] មានក្នុងស្តុករួចហើយ!`, 'warning');
    } else {
      inventoryData.unshift({
        barcode: code,
        status: 'In Stock',
        photo: 'https://placehold.co/100x100/1e293b/white?text=Snap',
        date: new Date().toLocaleString('km-KH'),
        operator: sessionUser?.name || 'Admin'
      });
      localStorage.setItem('stock_items_fixed', JSON.stringify(inventoryData));
      renderTable();
      updateStats();
      showToast(`បានបញ្ចូលស្តុក៖ ${code}`, 'success');
    }
  } else {
    const item = inventoryData.find(i => i.barcode === code);
    if (!item) {
      showToast(`រកមិនឃើញកូដ [${code}] ក្នុងស្តុកទេ!`, 'error');
    } else if (item.status === 'Opened') {
      showToast(`ទំនិញ [${code}] បើករួចហើយ!`, 'warning');
    } else {
      item.status = 'Opened';
      localStorage.setItem('stock_items_fixed', JSON.stringify(inventoryData));
      renderTable();
      updateStats();
      showToast(`បានបើកទំនិញ៖ ${code}`, 'success');
    }
  }

  setTimeout(() => { isCooldown = false; }, 1500);
}

function renderTable() {
  const tbody = document.getElementById('inventory-tbody');
  tbody.innerHTML = '';
  inventoryData.forEach(item => {
    const tr = document.createElement('tr');
    tr.className = "hover:bg-slate-800/40";
    tr.innerHTML = `
      <td class="px-4 py-3"><img src="${item.photo}" class="w-10 h-10 object-cover rounded-lg border border-slate-700"></td>
      <td class="px-4 py-3 font-mono font-bold text-cyan-400">${item.barcode}</td>
      <td class="px-4 py-3"><span class="px-2 py-0.5 rounded text-[10px] ${item.status === 'Opened' ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'}">${item.status}</span></td>
      <td class="px-4 py-3 text-slate-400">${item.operator}</td>
      <td class="px-4 py-3 text-right">
        <button onclick="deleteItem('${item.barcode}')" class="text-rose-400 hover:text-rose-300">លុប</button>
      </td>
    `;
    tbody.appendChild(tr);
  });
  lucide.createIcons();
}

function deleteItem(code) {
  if (confirm(`តើអ្នកចង់លុបទំនិញ ${code} មែនទេ?`)) {
    inventoryData = inventoryData.filter(i => i.barcode !== code);
    localStorage.setItem('stock_items_fixed', JSON.stringify(inventoryData));
    renderTable();
    updateStats();
    showToast('បានលុបទំនិញជោគជ័យ!', 'info');
  }
}

function updateStats() {
  const total = inventoryData.length;
  const unopened = inventoryData.filter(i => i.status === 'In Stock').length;
  const opened = inventoryData.filter(i => i.status === 'Opened').length;
  const rate = total > 0 ? Math.round((unopened / total) * 100) : 0;

  document.getElementById('stat-total').innerText = total;
  document.getElementById('stat-unopened').innerText = unopened;
  document.getElementById('stat-opened').innerText = opened;
  document.getElementById('stat-rate').innerText = `${rate}%`;
}

function handleAuditSubmit() {
  const code = document.getElementById('audit-manual-input').value.trim();
  if (!code) return;
  const exist = inventoryData.find(i => i.barcode === code);
  const tbody = document.getElementById('audit-tbody');
  const tr = document.createElement('tr');
  tr.innerHTML = `
    <td class="px-4 py-2 font-mono font-bold text-cyan-400">${code}</td>
    <td class="px-4 py-2">${exist ? `<span class="text-emerald-400">ត្រឹមត្រូវ (${exist.status})</span>` : `<span class="text-rose-400">គ្មានក្នុងប្រព័ន្ធ</span>`}</td>
    <td class="px-4 py-2 text-slate-400">${new Date().toLocaleTimeString()}</td>
  `;
  tbody.prepend(tr);
  document.getElementById('audit-manual-input').value = '';
}

function exportToExcel() {
  if (inventoryData.length === 0) return alert('គ្មានទិន្នន័យដើម្បី Export ទេ!');
  const ws = XLSX.utils.json_to_sheet(inventoryData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Stock");
  XLSX.writeFile(wb, "Stock_Data.xlsx");
}

function showToast(msg, type = 'info') {
  const wrapper = document.getElementById('toast-wrapper');
  const toast = document.createElement('div');
  toast.className = `p-3 rounded-2xl border text-xs shadow-xl pointer-events-auto bg-slate-900 border-slate-700 text-slate-200`;
  toast.innerText = msg;
  wrapper.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
