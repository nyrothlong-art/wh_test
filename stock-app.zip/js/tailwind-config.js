tailwind.config = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: { 500: '#06b6d4', 600: '#0891b2' }
      }
    }
  }
}
